<div class="footer">
<div class="footer-menu">
  <div class="footer-link first">
    <a class="slide to(about)" href="index.php?content=about">About</a>
  </div>
  <div class="footer-link">
    <a class="slide to(resume)" href="index.php?content=resume">Resume</a>
  </div>
  <div class="footer-link">
    <a class="slide to(portfolio)" href="index.php?content=portfolio">Portfolio</a>
  </div>
  <div class="footer-link last">
    <a class="slide to(contacts)" href="index.php?content=contacts">Contacts</a>
  </div>  
</div>
<p style="text-align:center">&copy; 2011 "Jump Box" Premium Template by iDangero.us. All Rights Reserved.</p>
</div>