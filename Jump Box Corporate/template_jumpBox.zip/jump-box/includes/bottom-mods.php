<div class="bottom-mods">
  <div class="bottom-mods2">
    <div class="bottom-mods3">
      <div class="module first">
        <h3 class="module-title">Contacts</h3>
        <p>114 Second Lane Street<br/>
          Rostov-na-Donu, 344013<br/>
          Russian Federation</p>
        <p><strong>Work:</strong> +7-863-246-3608<br/>
          <strong>Fax:</strong> +7-863-246-3608</p>
        <p><strong>Email:</strong> demo@idangero.us </p>
        <p><a class="cufoned slide to(contacts)" href="index.php?page=contacts">Send Message</a></p>
      </div>
      <div class="module">
        <h3 class="module-title">Latest Project</h3>
        <p><a class="popup" rel="700" href="folio/launcher.php"><img src="images/folio/launcher.jpg" width="180" alt="Launcher" /></a></p>
        <p style="text-align:center"><a class="cufoned slide to(portfolio)" href="index.php?page=contacts">Full Portfolio</a></p>
      </div>
      <div class="module">
        <h3 class="module-title">Recent Tweet</h3>
        <ul class="tweets"></ul>
        <p><a target="_blank" class="cufoned tweet-link" href="http://twitter.com/">Follow me on Twitter</a></p>
      </div>
      <div class="module last">
        <h3 class="module-title">JumpBox.Social</h3>
        <p><a href="#"><img src="images/social/twitter.png" width="40" height="40" alt="twiiter" /></a>
        <a href="#"><img src="images/social/facebook.png" width="40" height="40" alt="facebook" /></a>
        <a href="#"><img src="images/social/linkedin.png" width="40" height="40" alt="linkedin" /></a>
        <a href="#"><img src="images/social/myspace.png" width="40" height="40" alt="myspace" /></a>
        <a href="#"><img src="images/social/blogger.png" width="40" height="40" alt="blogger" /></a>
        <a href="#"><img src="images/social/youtube.png" width="40" height="40" alt="youtube" /></a>
        <a href="#"><img src="images/social/flickr.png" width="40" height="40" alt="flickr" /></a>
        <a href="#"><img src="images/social/digg.png" width="40" height="40" alt="digg" /></a>
        </p>
      </div>
      <div class="clear"></div>
    </div>
  </div>
</div>
