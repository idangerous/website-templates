<h2 class="content-heading">Jump Box Features</h2>
<h3 class="small-heading">Here are Jump Box features:</h3>
<ul>
  <li>Powered with jQuery</li>
  <li>Ajax Contact Form with validation</li>
  <li>Contact information is formatted in hCard microformat</li>
  <li>Special configuration for time animation</li>
  <li>Amazing animation without Flash</li>
  <li>Easy to use Popup Engine. It allows you to call popup windows (with a required size) with any HTML content inside</li>
  <li>Comes with 4 color themes</li>
  <li>Great browser compatibility (works in IE6 and higher)  </li>
  <li>Validates with XHTML 1.0</li>
  <li>100% tableless CSS</li>
  <li>Easy to redesign, has very simple and clear API</li>
</ul>

