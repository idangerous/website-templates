
    <div style="float:left; width:320px;margin-right:38px;">
      <h3 class="inner-heading">Personal Details</h3>
      <ul class="details">
        <li class="first"><span>Name:</span> John iDangerous Smith</li>
        <li><span>Day of Birth:</span> 3rd June 1986</li>
        <li><span>Nationality:</span> Russian</li>
        <li class="d-address"><span>Adress:</span> <span class="d-address2">114 Second Lane str, Rostov-na-Donu city, Russia</span></li>
        <li><span>Phone:</span> +7-908-191-0608</li>
        <li class="last"><span>Email:</span> demo@idangero.us</li>
      </ul>
    </div>
    <div style="float:left; width:320px">
      <h3 class="inner-heading">Technical Skills</h3>
      <h3 class="small-heading">Adobe Photoshop</h3>
      <p class="stars">
        <span class="star1"></span>
        <span class="star1"></span>
        <span class="star1"></span>
        <span class="star1"></span>
        <span class="star1"></span>
        <span class="star1"></span>
        <span class="star2"></span>
        <span class="star2"></span>
      </p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vestibulum tellus non neque hendrerit condimentum.</p>
      <h3 class="small-heading">Microsoft Office</h3>
      <p class="stars">
        <span class="star1"></span>
        <span class="star1"></span>
        <span class="star1"></span>
        <span class="star1"></span>
        <span class="star2"></span>
        <span class="star2"></span>
        <span class="star2"></span>
        <span class="star2"></span>
      </p>
      <p>Nullam vestibulum tellus non neque hendrerit condimentum. Sed suscipit leo eu elit pellentesque eu porttitor tellus tempus.</p>
    </div>
    <div class="clear"></div>
  <h3 class="inner-heading">Work Expirience</h3>
  <div class="resume-item">
    <h3 class="small-heading">Postman</h3>
    <h4 class="item-descr">iDangero.us <span class="period">June 2010 - Present</span></h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vestibulum tellus non neque hendrerit condimentum. Sed suscipit leo eu elit pellentesque eu porttitor tellus tempus. Fusce in libero nibh, a tempus mi. Duis imperdiet volutpat erat sed sollicitudin.</p>
  </div>
  <div class="resume-item">
    <h3 class="small-heading">Carrier</h3>
    <h4 class="item-descr">Toy Cars Factory <span class="period">January 2010 - June 2010</span></h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vestibulum tellus non neque hendrerit condimentum. Sed suscipit leo eu elit pellentesque eu porttitor tellus tempus. Fusce in libero nibh, a tempus mi. Duis imperdiet volutpat erat sed sollicitudin.</p>
  </div>
  <h3 class="inner-heading">Education</h3>
  <div class="resume-item">
    <h3 class="small-heading">iDangero.us State University <span class="period">2006 - 2010</span></h3>
    <h4 class="item-descr">Web Designer</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vestibulum tellus non neque hendrerit condimentum. Sed suscipit leo eu elit pellentesque eu porttitor tellus tempus. Fusce in libero nibh, a tempus mi. Duis imperdiet volutpat erat sed sollicitudin.</p>
  </div>
  <div class="resume-item">
    <h3 class="small-heading">High School <span class="period">2002 - 2006</span></h3>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vestibulum tellus non neque hendrerit condimentum. Sed suscipit leo eu elit pellentesque eu porttitor tellus tempus. Fusce in libero nibh, a tempus mi. Duis imperdiet volutpat erat sed sollicitudin.</p>
  </div>
  <p style="text-align:center"><a class="button" onclick="window.print();return false;" href="#">Print Resume</a> <a class="button" href="#">Download Resume</a></p>


