<h2 class="content-heading">LauncherX</h2>
<h3 class="small-heading">Premium Countdown Template</h3>
<p>LauncherX is the premium Ajax based countdown template designed by iDangero.us. It is designed for temporary usage until the main site is under construction.</p>
<p align="center"><img src="images/launcherx.jpg" width="590" height="300" alt="LauncherX" /></p>
<p>It comes with awesome animated clock with a countdown to the grand opening date, brief information about the main site (or company) and Ajax Contact form with validation. Also, there is an opportunity for visitors to leave their email address to be informed when the site will open.</p>
<p>All content is loaded "on the fly" into popup window. Smooth and good looking animation and Ajax features of this template are realized with the JavaScript jQuery library.</p>
<h3 class="small-heading">Here are LauncherX features:</h3>
<ul>
  <li> Powered with jQuery  </li>
  <li>Ajax Contact Form with validation</li>
  <li> Awesome animation without Flash</li>
  <li>Easy to use Popup Engine. It allows you to call popup windows (with a required size) with any HTML content inside  </li>
  <li>Comes with 3 color themes and 2 clock skins  </li>
  <li>Great browser compatibility (works in IE6 and higher)  </li>
  <li>Validates with HTML5 Doctype  </li>
  <li>100% tableless CSS  </li>
  <li>Easy to redesign, has very simple and clear API </li>
</ul>
